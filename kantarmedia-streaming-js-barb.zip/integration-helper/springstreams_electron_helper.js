// This file is required by the index.html file and will
// be executed in the renderer process for that window.
// All of the Node.js APIs are available in this process.

const ElectronCookies = require('@exponent/electron-cookies');
ElectronCookies.enable({ origin: 'http://example.com/index.html' });

const myModule = require('./springstreams');
var sensors;
if (typeof(sensors) == 'undefined') // Checking if the instance of the sensor is already created. If not we are creating one. This ensures that we will instantiate spring sensor only once!!
    sensors = new myModule.SpringStreams('test');

var desc = {
    "sx": 'screen width',
    "sy": 'screen height',
    "stream": "name of stream"
};


var vid = 'Get the video information from player'

/*------------------------------------------Implementing stream adapter same as before---------------------------------- */
var adapter = {
    "getMeta": function(id) {
        return {
            "pl": "testPlayer",
            "plv": "1.0.0",
            "sx": vid.videoWidth,
            "sy": vid.videoHeight
        }
    },
    "getPosition": function(id) {
        console.log("Pos: " + Math.round(vid.currentTime));
        return Math.round(vid.currentTime);

    },
    "getDuration": function(id) {
        console.log("Duration: " + Math.round(vid.duration));
        return Math.round(vid.duration);
    }
}



handle = sensors.track("testplayer", desc, adapter); // Calling Track method of Sensor !!


// use this to bind app close event
window.onbeforeunload = function(e) {
    sensors.unload();
}

// These events help in handling app background and foreground
document.addEventListener("visibilitychange", function() {
    console.log(document.hidden, document.visibilityState);

    if (document.hidden == true) {
        handle.stop();
    }
    if (document.hidden == false) {
        handle = sensors.track("testplayer", desc, adapter); // Calling Track method of Sensor !!
    }
}, false);