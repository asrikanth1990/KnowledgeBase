Brightcove Streaming Plugin
	1. Unzip the folder
	2. Go to standalone folder and extract kantarmedia-streaming-brightcove.js file
	3. upload the file into any server and start using the plugin. For more information on how to integrate, please follow the documentation provided in BrightcoveHTML5StreamingSensor.pdf