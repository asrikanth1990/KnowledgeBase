Kantarmedia-streaming-libjscript Release

This release is targeted on PS stations, Libjscript Framework, aimed on the measurement on streaming content.

The usage of the library is almost the same with other spring js libs, more info can be found here: https://confluence.spring.de/display/public/Implementation+of+Stream+Measurement.

Before the implementation, please take following issues into consideration:

1. The lib is designed based on Libjscript Framework, it contains particular API calls.
2. The communication within the lib is all on http, no special certificate is required.
3. The library manages a file on local storage, please make sure the application owns the right to write files.
4. The springstreams library requires the third-party library ‘CryptoJS’. Please also include the lib into your project, the file is attached in the release package.

