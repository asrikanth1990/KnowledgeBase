Electron
	1. Please import springstreams.js and corresponding plug-ins from zip and add it as dependency into electron project you want to use
	2. Create a pageContext object like this: var pageContext_springstreams = new PageContext();
	3. Initialize the SpringStreams object and call SpringStreams.setPageContext(pageContext_springstreams)
	4. Steps to add springstreams.js remains same if you use default electron structure (using index.html)
	5. If you want to include directly into javascript without using HTML . you have to follow below Steps
		* Add this to end of springstreams linrary - module.exports = {SpringStreams}
		* In the javascript file import the file using - const myModule = require('./springstreams');
		* Initiate sensors using - sensors = new myModule.SpringStreams('test');
	6. More information on how to use our streaming sensors with electron can be found in integration-helper/springstreams_electron_helper.js (you can use this in any of your electron renderer js files)
	7. Please follow below steps for accessing cookies in case of panelApp
		* Install electron-cookies plugin into project via npm (more information can be found here : https://github.com/expo/electron-cookies)
		* Add these into implementaion file 
			const ElectronCookies = require('@exponent/electron-cookies');
			ElectronCookies.enable({ origin: 'https://example.com/web/index.html' });