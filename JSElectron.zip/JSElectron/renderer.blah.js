// This file is required by the index.html file and will
// be executed in the renderer process for that window.
// All of the Node.js APIs are available in this process.
//require('./springstreams')
//import { SpringStreams } from './springstreams'
const ElectronCookies = require('@exponent/electron-cookies');
var { ipcRenderer, remote } = require('electron');
var main = remote.require("./main.js");


//const SpringStreams = require('./springstreams');
let fs = require('fs');
ElectronCookies.enable({ origin: 'http://example.com/index.html' });
var sensors;
var pageContext_springstreams = new PageContext();
SpringStreams.prototype.setPageContext(pageContext_springstreams);
var vid = document.getElementById("testVideo");
var div = document.getElementById('req');
var filename = os.homedir() + '/cookie.txt';
if (typeof(sensors) == 'undefined') // Checking if the instance of the sensor is already created. If not we are creating one. This ensures that we will instantiate spring sensor only once!!
    sensors = new SpringStreams('box30107');
var desc = {
    "sx": window.innerWidth,
    "sy": window.innerHeight,
    "stream": vid.src
};

window.onload = function() {
    setTimeout(function() {
        console.log(ipcRenderer.sendSync('synchronous-message', 'ping'));
        //document.cookie = 'i00=' + ipcRenderer.sendSync('synchronous-message', 'ping');
    }, 200)
};

/*------------------------------------------Implementing stream adapter ---------------------------------- */
var adapter = {
    "getMeta": function(id) {
        return {
            "pl": "testPlayer1008",
            "plv": "1.0.0",
            "sx": vid.videoWidth,
            "sy": vid.videoHeight
        }
    },
    "getPosition": function(id) {
        // if(debugFlag)    
        // console.log("Pos: " + Math.round(vid.currentTime));
        return Math.round(vid.currentTime);

    },
    "getDuration": function(id) {
        // if(debugFlag)    
        console.log("Duration: " + Math.round(vid.duration));
        return Math.round(vid.duration);
    }
}

handle = sensors.track("testplayer", desc, adapter); // Calling Track method of Sensor !!
sensors.debug = function(v) {
    //if(debugFlag)   
    console.log('Request:', v);
    var test = '<p>' + v + '</p>';
    //div.insertAdjacentHTML('beforeend', test);
}

window.onbeforeunload = function(e) {
    sensors.unload();
}

function clear() {
    document.getElementById('req').innerHTML = '';
}

function changeSrc() {
    //  vid.src = 'http://techslides.com/demos/sample-videos/small.mp4';
    //  desc.stream = vid.src;
    // handle = sensors.track("testplayer", desc, adapter);

    if (this.textContent == 'back')
        window.location.href = 'index.html';
    else
        window.location.href = 'pagetwo.html';
}

function loadAndDisplayCookie() {

    //Check if file exists
    if (fs.existsSync(filename)) {
        let data = fs.readFileSync(filename, 'utf8').split(':')

        alert(data[1]);

    } else {
        console.log("File Doesn\'t Exist. Creating new file.")
        fs.writeFile(filename, 'cookie:sxrySK666fjK7788', (err) => {
            if (err)
                console.log(err)
        })
    }
}

function forward() {
    vid.currentTime += document.getElementById('dur').value;
}

function rewind() {
    vid.currentTime -= document.getElementById('dur').value;
}

function go() {
    var min = (document.getElementById('min').value == '') ? 0 : document.getElementById('min').value;
    var sec = (document.getElementById('sec').value == '') ? 0 : document.getElementById('sec').value;
    vid.currentTime = min * 60 + parseInt(sec);
}

document.addEventListener("visibilitychange", function() {
    console.log(document.hidden, document.visibilityState);

    if (document.hidden == true) {
        // handle.stop();
    }
    if (document.hidden == false) {
        //      handle = sensors.track("testplayer", desc, adapter); // Calling Track method of Sensor !!
    }
}, false);

document.querySelector('#btn').addEventListener('click', clear)
document.querySelector('#fwd').addEventListener('click', forward)
document.querySelector('#rwd').addEventListener('click', rewind)
document.querySelector('#goToPos').addEventListener('click', go)
document.querySelector('#srcChange').addEventListener('click', changeSrc)
    //document.querySelector('#cookie').addEventListener('click', loadAndDisplayCookie)