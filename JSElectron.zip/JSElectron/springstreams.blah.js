/*
 *  THIS IS THE DEVELOPMENT VERSION
 * 
 *  bEFORE ReLEASING, COMPRESS WITH java -jar spring-sensors/build/yuicompressor.jar  !!!
 * 
 * 
 */

/**
 * The sensor which exists exactly one time in a site page and manage 
 * all streaming measurement issues.
 * SpringStreams(site), specify the site name within the constructor
 * @class SpringStreams
 * @param {String} site The sitename 
 * @description If you have more questions, please contact <a href="mailto:KA_DE_support@kantarmedia.com"> Kantar Media</a>.
 */

"use strict";

function SpringStreams(site) {
    this.version = "2.0.0";
    var domain = "2cnt.net";

    var collectorDelay = 200;
    var syncDelay = 2000;

    var defaultSite = "default";
    var streamdata = new Array();
    this.namespace = "com.kma.springstreams";
    // synchronize ever 20 seconds of linear video 
    this.syncrate = 20;
    // after 1 second of pause (6 events of the timecollect timer means bit more than one second) synchronize data 
    this.pausesync = 6;
    // define the maximum amount of states to be tracked
    this.maxstates = 50;

    var m = {
        '+': '%2B',
        ',': '%2C',
        ';': '%3B',
        '=': '%3D',
        '~': '%7E',
        '*': '%2A',
        "'": '%27',
        '!': '%21',
        '(': '%28',
        ')': '%29'

    };

    var thiz = this;
    this.pageContext;
    var syncrates;

    configure(getConfig());

    // constructor
    if (site) defaultSite = site;
    initTimers();


    function getConfig() {

        var config = {
            "2cnt.net": {
                "syncrates": [3, 7, 10, 10, 10, 10, 10, 60]
            }
        };
        return config;
    }

    function configure(config) {
        var domainConfig;
        if (config) {
            for (var att in config) {
                if (att == domain) {
                    domainConfig = config[att];
                }
            }
            if (domainConfig) {
                configureSyncRates(domainConfig.syncrates);
            }
        }
    }

    function configureSyncRates(arr) {
        if (arr) syncrates = arr;
    }

    function getSyncRates() {
        return syncrates;
    }
    this.getSyncRates = getSyncRates; // public

    /**
     * @memberof SpringStreams
     * @method track
     * @description Call this method to start the tracking of a streaming
     *              content. The sensor gets access to the stream by the given
     *              adapter. The variable <code>stream</code> is mandatory in
     *              the attributes object. the Stream can be described by the
     *              atts parameter.
     * 
     * @param stream
     *            {String} stream The name of the stream content
     * @param att
     *            {Map} att A map which contains information about the streaming
     *            content.
     * @param adapter
     *            {StreamAdapter} adapter The stream adapter which handles the
     *            access to the underlying streaming content.
     * @returns A Stream object.
     */
    function track(stream, att, adapter) {
        if (thiz.pageContext === undefined) thiz.pageContext = thiz.defaultPageContext;
        if (!stream) return;
        var ret = new Stream(this, stream, att, adapter);
        streamdata.push(ret); // SET
        return ret;
    }
    this.track = track; // public

    // datacollection functions
    function initTimers() {
        setInterval(doUpdate, collectorDelay);
        setInterval(doSync, syncDelay);
    }

    /**
     * @memberof SpringStreams
     * @method unload
     * @description External callback, synchronize and unload all the open streams.
     */
    function unload() {
        for (var i = 0; i < streamdata.length; ++i) {
            try {
                streamdata[i].stop();
            } catch (e) {
                error(e);
            }
        }
    }
    this.unload = unload; // public

    function doUpdate(te) {
        for (var i = 0; i < streamdata.length; ++i) {
            try {
                streamdata[i].update(te);
            } catch (e) {
                error(e);
            }
        }
    }
    this.doUpdate = doUpdate; // public

    function doSync(te) {
        for (var i = 0; i < streamdata.length; ++i) {
            try {
                streamdata[i].sync(te);
            } catch (e) {
                error(e);
            }
        }
    }
    this.doSync = doSync; // public

    // functions used to synchronize the data with the given system

    function error(v) {
        send("", v);
    }
    this.error = error; //  public


    function sencode(meta, v) {
        return sf([
            [
                meta,
                v
            ]
        ]);
    }

    function findSite(v) {
        if (v && v.site != undefined) return v.site;
        return defaultSite;
    }

    function debug(v) {}
    this.debug = debug;

    function pr() {
        if (thiz.pageContext.getWindowLocationURL() === undefined)
            return 'http://';

        if ('https' == thiz.pageContext.getWindowLocationURL().slice(0, 5)) {
            return 'https://ssl-';
        } else
            return 'http://';
    }



    function lsid() {
        if (!thiz.nlso)
            try {
                var l = "";
                var key = "i00";

                if (thiz.pageContext.getUniqueId != undefined) {
                    key = domain;
                }

                l = thiz.pageContext.getLocalStorageItem(key);


                if (l) {
                    return '&c=' + l;

                } else {
                    var ta = '0000',
                        id = ta + Math.ceil((new Date()).getTime() / 1000).toString(16) + (0x8000 | Math.random() * 0xffff).toString(16) + ta;

                    thiz.pageContext.setLocalStorageItem(key, id);


                }
            } catch (e) {
                console.log("error" + e);

            }
        return '';
    }

    function send(meta, what) {
        if (typeof(what.stream) == 'undefined' || what.stream == '') {
            console.error('Stream is mandatory for measurement');
            thiz.debug('Stream is mandatory for measurement');
        } else {

            var s = pr() + findSite(what) + "." + domain + "/j0=" + sencode(meta, what) +
                '?lt=' + (new Date()).getTime().toString(36) +
                lsid();

            thiz.pageContext.preloadImage(s);

            thiz.debug(s);
        }
    }
    this.send = send; // public

    // private encoding functions, note that the compression is not active here
    // for further information about the encoding see the javascript variant spring.js 

    function sf(v) {
        var a;
        var i;
        var k;
        var l;
        var r = /[+&,;=~!*'()]/g;
        var d;
        switch (typeof v) {
            case 'string':
                return r.test(v) ? encodeURIComponent(v).replace(r, function(a) {
                    var c = m[a];
                    if (c) {
                        return c;
                    }
                    return a;
                }) : encodeURIComponent(v);


            case 'number':
                return isFinite(v) ? v.toString() : 'null';

            case 'boolean':
            case 'null':
                return v.toString();

            case 'object':
                if (!v) {
                    return 'null';
                }
                a = [];
                if (typeof v.length == 'number' && !(v.propertyIsEnumerable('length'))) {
                    l = v.length;
                    for (i = 0; i < l; i += 1) {
                        a.push(sf(v[i]) || 'null');
                    }
                    return ',' + a.join('+') + ';';
                }

                for (k in v) {
                    if (typeof k == 'string') {
                        if (k != 'site') {
                            d = sf(v[k]);
                            if (d) {
                                a.push(sf(k) + '=' + d);
                            }
                        }
                    }
                }
                return ',' + a.join('+') + ';';
        }
        return '';
    }

    /**
     * @description The {@link Stream} object will be returned when the method
     *              SpringStreams.track(stream, atts, adapter) is called.
     * 
     * The method {@link stop()} can be called if the measurement should be
     * stopped. It is not possible to reactivate the measurement. For that
     * purpose the method SpringStreams.track(stream, atts, adapter) has to be
     * called again.
     * @class Stream
     * @param aCollector {SpringStreams} The collector
     * @param aStreamName
     *            {String} stream The name of the stream content
     * @param theAttributes
     *            {Map} att A map which contains information about the streaming
     *            content.
     * @param anAdapter
     *            {StreamAdapter} adapter The stream adapter which handles the
     *            access to the underlying streaming content.
     */
    function Stream(aCollector, aStreamName, theAttributes, anAdapter) {
        /**
         * Generates a random UID.
         * @return the generated random UID.
         */
        function generateUid() {
            var randomUidPart = Math.round((Math.random() * 10000000000)).toString(36);
            var millisUidPart = new Date().getTime().toString(36);
            return millisUidPart + randomUidPart;
        }

        var id = generateUid();
        var start = Math.round(new Date().getTime() / 1000);
        var collector;
        var ns;
        var playStates;
        var attributes;
        var state = [0, 0, start.toString(36)];
        var pause = 0;
        var lastSync = 0;
        var doSync = true; // initial sync
        var closed = false;
        var adapter;

        var syncrate;
        var syncrates;
        var syncratesIndex;

        collector = aCollector;
        ns = aStreamName;
        if (anAdapter)
            adapter = anAdapter;
        else
            adapter = collector.HTML5Adapter;

        attributes = getAttributes(theAttributes);
        playStates = new Array();
        playStates.push(state);

        syncratesIndex = 0;
        syncrate = aCollector.syncrate;
        syncrates = aCollector.getSyncRates();
        // initial set of configured syncrate
        // if its configured otherwise use default syncrate from SpringStreams.syncrate
        switchSyncRate();


        function getAttributes(att) {
            var a = new Object();
            for (var k in att) {
                a[k] = att[k];
            }
            return a;
        }

        function addPlayState(v) {
            if (playStates.length < collector.maxstates)
                playStates.push(v);
        }

        function addState(now) {
            state = [now, now, Math.round(new Date().getTime() / 1000).toString(36)];
            addPlayState(state);
            doSync = true;
            pause = 0;
        }

        function switchSyncRate() {
            if (syncrates != null) {
                if (syncratesIndex < syncrates.length) {
                    syncrate = syncrates[syncratesIndex++];
                    collector.debug("switch syncrate to " + syncrate);
                }
            }
        }

        /**
         * This function is called by the spring-track-timer in subsecond
         * intervals and collects the current stream position
         */
        function update(te) {
            if (closed) return;
            var lasttime = state[1];
            var now = lasttime;
            try {
                // there may be api problems ignore them
                now = Math.round(adapter.getPosition(ns));
            } catch (e0) {}
            try {
                if (lasttime == now) {
                    // pause? sync the stream immediately
                    if (pause >= 0) {
                        pause++;
                        if (pause == collector.pausesync) doSync = true;
                    }
                    return;
                }

                if (pause >= collector.pausesync) {
                    addState(now);
                } else if (lasttime < now - 1) {
                    // forward
                    addState(now);
                } else if (lasttime > now) {
                    // backward
                    addState(now);
                } else {
                    // linear
                    state[1] = now;
                    if (state[1] - state[0] >= syncrate) {
                        if (now - lastSync >= syncrate) {
                            doSync = true;
                            switchSyncRate();
                        }
                    }
                    pause = 0;
                }
            } catch (e) {
                error = true;
                collector.error(e);
            }
        }
        this.update = update; // public

        /**
         * Sync and stop the stream tracking immediately.
         * @method stop
         * @description Sync and stop the stream tracking immediately.
         */
        function stop() {
            if (closed) return;
            doSync = true;
            closed = true;
            sync(null);
        }
        this.stop = stop; // public

        /**
         * this function is called by the spring-sync-timer and perfoms
         * synchronization of the data collected
         */
        function sync(te) {
            if (doSync) {
                try {
                    if (ns.width)
                        attributes["sx"] = ns.width;
                    if (ns.videoWidth)
                        attributes["sx"] = ns.videoWidth;
                    if (ns.height)
                        attributes["sy"] = ns.height;
                    if (ns.videoHeight)
                        attributes["sy"] = ns.videoHeight;
                } catch (e) {};
                if (thiz.pageContext.getUniqueId != undefined) {
                    attributes["psid"] = thiz.pageContext.getUniqueId();
                }
                attributes["uid"] = id;
                attributes["pst"] = playStates;
                var meta;
                try {
                    if (!attributes["dur"] || attributes["dur"] == 0)
                        attributes["dur"] = adapter.getDuration(ns);
                } catch (e) {};
                try {
                    meta = adapter.getMeta(ns);
                    if (thiz.pageContext.getDeviceID !== undefined && thiz.pageContext.getDeviceID() !== undefined) meta[thiz.pageContext.getDeviceID()["id_name"]] = thiz.pageContext.getDeviceID()["id_value"];
                } catch (e) {}

                attributes["vt"] = (Math.round(new Date().getTime() / 1000)) - start;
                attributes["v"] = 'JS-Streaming-' + thiz.version;

                collector.send(meta, attributes);

                lastSync = state[1];
            }
            doSync = false;
        }
        this.sync = sync; // public
    }





    /*
     * 
     * 
     * metadata and adapters
     * 
     * 
     * 
     */

    this.defaultPageContext = {
        "getLocalStorageItem": getLocalStorageItem,
        "setLocalStorageItem": setLocalStorageItem,
        "preloadImage": preloadImage,
        "getWindowLocationURL": getWindowLocationURL,
    }

    this.HTML5Adapter = {
        "getMeta": getMetaH5,
        "getPosition": getPositionH5,
        "getDuration": getDurationH5
    }

    this.DefaultAdapter = {
        "getMeta": getMetaDefault,
        "getPosition": getPositionDefault,
        "getDuration": getDurationDefault
    }

    this.WMStreamAdapter = {
        "getMeta": getMetaWM,
        "getPosition": getPositionWM,
        "getDuration": getDurationWM
    }

    this.RVStreamAdapter = {
        "getMeta": getMetaRV,
        "getPosition": getPositionRV,
        "getDuration": getDurationRV
    }

    function getMetaH5(ns) {
        return {
            "pl": "HTML 5 Video",
            "pv": "HTML 5",
            "sx": screen.width,
            "sy": screen.height
        }
    }

    function getDurationH5(ns) {
        return Math.round(ns.duration);
    }

    function getPositionH5(ns) {
        return ns.currentTime;
    }

    // default
    function getMetaDefault(ns) {
        return {
            "pl": "DEF",
            "pv": version,
            "sx": screen.width,
            "sy": screen.height
        }
    }

    function getPositionDefault(ns) {
        return new Date().getTime() / 1000;
    }

    function getDurationDefault(ns) {
        return 0;
    }


    // ms mediaplayer
    function getMetaWM(ns) {
        return {
            // META in the source
            "pl": "MSWM",
            "plv": ns.versionInfo,
            "sx": screen.width,
            "sy": screen.height
        }
    }

    function getPositionWM(ns) {
        if (ns.CurrentPosition) return ns.CurrentPosition;
        if (ns.currentPosition) return ns.currentPosition;
        if (ns.controls)
            if (ns.controls.currentPosition) return ns.controls.currentPosition;
        if (ns.Controls)
            if (ns.Controls.currentPosition) return ns.Controls.currentPosition;
        return 0;
    }


    function getDurationWM(ns) {
        if (ns.currentMedia) {
            if (ns.currentMedia.Duration)
                return ns.currentMedia.Duration;
            if (ns.currentMedia.duration)
                return ns.currentMedia.duration;
        } else if (ns.CurrentMedia) {
            if (ns.CurrentMedia.duration)
                return ns.CurrentMedia.duration;
            if (ns.CurrentMedia.Duration)
                return ns.CurrentMedia.Duration;
        }
    }


    // realplayer
    function getMetaRV(ns) {
        return {
            // META in the source
            "pl": "RV",
            "plv": ns.GetVersionInfo(),
            "sx": screen.width,
            "sy": screen.height
        }
    }


    function getPositionRV(ns) {
        return (ns.GetPosition() / 1000);
    }

    function getDurationRV(ns) {
        return (ns.GetLength() / 1000)
    }

    function setLocalStorageItem(key, value) {
        localStorage.setItem(key, value);
    }

    function getLocalStorageItem(key) {
        return localStorage.getItem(key);
    }

    function preloadImage(s) {
        (new Image()).src = s;
    }

    function getWindowLocationURL() {
        return document.location.href;
    }
}

SpringStreams.prototype.setPageContext = function(pageContext) {
    this.pageContext = pageContext;

}

module.exports = SpringStreams