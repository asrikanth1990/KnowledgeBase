var PageContext = function() {
    this.namespace = "com.kma.springstreams";
};

// preload an image, implement it with the specific SDK API
PageContext.prototype.preloadImage = function(s) {
    (new Image()).src = s;
}

PageContext.prototype.getLocalStorageItem = function(key) {
    return localStorage.getItem(key);
}

PageContext.prototype.setLocalStorageItem = function(key, value) {
    localStorage.setItem(key, value);
}


PageContext.prototype.getWindowLocationURL = function() {
    return 'https';
}